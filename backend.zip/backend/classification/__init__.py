"""Unified market signal classification."""
